globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/95a03aa8effbcbd5.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/514487a3a9cc9253.js",
    "static/chunks/e9ab39bb7684f2ba.js",
    "static/chunks/78398ea08bc082dc.js",
    "static/chunks/turbopack-045247f901182d61.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];